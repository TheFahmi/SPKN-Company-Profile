import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Kontak Kami',
  description: 'Hubungi kami untuk informasi lebih lanjut tentang layanan percetakan kami',
}; 